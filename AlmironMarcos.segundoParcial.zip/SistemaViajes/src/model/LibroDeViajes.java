/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import persistence.CSVSerializable;

/**
 *
 * @author marco
 * @param <T>
 */
public class LibroDeViajes<T extends CSVSerializable> {

    private List<T> viajes = new ArrayList<>();

    public void agregar(T indice) {
        Objects.requireNonNull(viajes, "Elemento nulo");
        viajes.add(indice);
    }

    public boolean eliminar(T indice) {
        Objects.requireNonNull(viajes, "Elemento nulo");
        return viajes.remove(indice);
    }

    public T obtener(int indice) {
        validarIndice(indice);
        return viajes.get(indice);
    }

    private void validarIndice(int indice) {
        if (indice < 0 || indice >= viajes.size()) {
            throw new IndexOutOfBoundsException("Indice fuera de rango");
        }
    }

    public void paraCadaElemento(Consumer<T> accion) {
        for (T item : viajes) {
            accion.accept(item);
        }
    }

    public List<T> filtrar(Predicate<T> criterio) {
        List<T> filtrada = new ArrayList<>();
        for (T item : viajes) {
            if (criterio.test(item)) {
                filtrada.add(item);
            }
        }
        return filtrada;
    }

    public void ordenar(Comparator<? super T> comp) {
        viajes.sort(comp);
    }

    public void ordenar() {
        viajes.sort((Comparator<T>) Comparator.naturalOrder());
    }

    public void guardarEnCSV(String path) throws IOException {

        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(path))) {

            escritor.write(ViajeTemporal.toHeaderCSV());
            for (T v : viajes) {
                escritor.write(v.toCSV());
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void cargarDesdeCSV(String path, Function<String, T> charge) throws IOException {
        try (BufferedReader lector = new BufferedReader(new FileReader(path))) {
            String linea;
            lector.readLine();

            while ((linea = lector.readLine()) != null) {
                if (!linea.isEmpty()) {
                    viajes.add(charge.apply(linea));
                }
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void guardarEnArchivo(String path) throws IOException {
        try (ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(path))) {
            serializador.writeObject(viajes);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException {

        try (ObjectInputStream deser = new ObjectInputStream(new FileInputStream(path))) {
            viajes = (List<T>) deser.readObject();
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }

    }

}
