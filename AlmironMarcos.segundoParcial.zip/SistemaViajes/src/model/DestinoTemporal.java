/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package model;

/**
 *
 * @author marco
 */
public enum DestinoTemporal {
    HILL_VALLEY_1955,
    HILL_VALLEY_1985,
    HILL_VALLEY_2015,
    FAR_WEST_1885,
    REALIDAD_ALTERNATIVA,
    LINEA_RESTAURADA

}
