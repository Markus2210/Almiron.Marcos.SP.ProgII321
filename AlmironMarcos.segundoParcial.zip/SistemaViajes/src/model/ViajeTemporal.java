/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import persistence.CSVSerializable;

/**
 *
 * @author marco
 */
public class ViajeTemporal implements Comparable<ViajeTemporal>, CSVSerializable {

    private static final long serialVersionUID = 1L;
    private int id;
    private String descripcion;
    private String viajero;
    private DestinoTemporal destino;

    public ViajeTemporal(int id, String descripcion, String viajero, DestinoTemporal destino) {
        this.id = id;
        this.descripcion = descripcion;
        this.viajero = viajero;
        this.destino = destino;
    }

    public int getId() {
        return id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getViajero() {
        return viajero;
    }

    public DestinoTemporal getDestino() {
        return destino;
    }

    @Override
    public int compareTo(ViajeTemporal o) {
        return Integer.compare(id, o.id);

    }

    public static ViajeTemporal fromCSV(String viajeCSV) {
        viajeCSV = viajeCSV.substring(0, viajeCSV.length());
        String[] datos = viajeCSV.split(",");
        return new ViajeTemporal(Integer.parseInt(datos[0]), datos[1], datos[2], DestinoTemporal.valueOf(datos[3]));
    }

    public static String toHeaderCSV() {
        return "id,descripcion,viajero,destino\n";
    }

    @Override
    public String toCSV() {
        return id + "," + descripcion + "," + viajero + "," + destino + "\n";
    }

    @Override
    public String toString() {
        return "ViajeTemporal -> " + "id: " + id + " | descripcion: " + descripcion + " | viajero: " + viajero + " | destino: " + destino;
    }

}
