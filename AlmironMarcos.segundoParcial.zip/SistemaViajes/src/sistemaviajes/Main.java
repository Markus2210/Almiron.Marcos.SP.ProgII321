package sistemaviajes;

import config.RutasArchivos;
import java.io.IOException;
import model.DestinoTemporal;
import model.LibroDeViajes;
import model.ViajeTemporal;

public class Main {

    public static void main(String[] args) {
        try {

            LibroDeViajes<ViajeTemporal> libro = new LibroDeViajes<>();

            libro.agregar(new ViajeTemporal(1, "Salvar a George McFly", "Marty McFly", DestinoTemporal.HILL_VALLEY_1955));
            libro.agregar(new ViajeTemporal(2, "Buscar el Almanaque Deportivo", "MartyMcFly", DestinoTemporal.HILL_VALLEY_2015));
            libro.agregar(new ViajeTemporal(3, "Impedir la realidad alternativa de Biff", "Doc Brown", DestinoTemporal.REALIDAD_ALTERNATIVA));
            libro.agregar(new ViajeTemporal(4, "Rescatar a Clara en el puente", "Doc Brown", DestinoTemporal.FAR_WEST_1885));
            libro.agregar(new ViajeTemporal(5, "Restaurar la línea temporal original", "Marty McFly", DestinoTemporal.LINEA_RESTAURADA));

            System.out.println("Viajes en el tiempo:");
            libro.paraCadaElemento(v -> System.out.println(v));

            System.out.println("\nViajes a 1955:");
            libro.filtrar(v -> v.getDestino() == DestinoTemporal.HILL_VALLEY_1955)
                    .forEach(v -> System.out.println(v));

            System.out.println("\nViajes que contienen 'almanaque':");
            libro.filtrar(d -> d.getDescripcion().toLowerCase().contains("almanaque"))
                    .forEach(d -> System.out.println(d));

            System.out.println("\nViajes ordenados por ID:");
            libro.ordenar((v1, v2) -> Integer.compare(v1.getId(), v2.getId()));
            libro.paraCadaElemento(i -> System.out.println(i));

            System.out.println("\nViajes ordenados por descripción:");
            libro.ordenar((v1, v2) -> v1.getDescripcion().compareTo(v2.getDescripcion()));

            libro.guardarEnArchivo(RutasArchivos.getRutaBINString());

            LibroDeViajes<ViajeTemporal> libroCargado = new LibroDeViajes<>();

            libroCargado.cargarDesdeArchivo(RutasArchivos.getRutaBINString());

            System.out.println("\nViajes cargados desde archivo binario:");
            libroCargado.paraCadaElemento(System.out::println);

            libro.guardarEnCSV(RutasArchivos.getRutaCSVString());
            libroCargado.cargarDesdeCSV(RutasArchivos.getRutaCSVString(), fromCSV -> ViajeTemporal.fromCSV(fromCSV));

            System.out.println("\nViajes cargados desde archivo CSV:");
            libroCargado.paraCadaElemento(System.out::println);

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
