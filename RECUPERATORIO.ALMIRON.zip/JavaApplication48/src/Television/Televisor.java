/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Television;

public class Televisor {

    private final String marca;
    private final double tamanio;
    private int canal;
    private int volumen;
    private int volumenAnterior;
    private boolean estaEncendido;
    private static int SET_CANAL = 14;
    private final static int MAX_CANAL = 99;
    private final static int MIN_CANAL = 1;
    private static int SET_VOLUMEN = 14;
    private final static int MAX_VOL = 20;
    private final static int MIN_VOL = 0;
    private boolean estaMute;
    private static final int INITIAL_SERIE = 100000;
    private static int nextSerie = INITIAL_SERIE;
    private final int nroSerie;

    public Televisor(String marca, double tamanio) {

        validarTamnio(tamanio);
        this.tamanio = tamanio;
        this.marca = marca;
        this.nroSerie = nextSerie++;
    }
    
    private void validarMarca(String marca){
        if(marca == null || marca.isBlank() || marca.isEmpty() || marca.length() < 2){
            throw new IllegalArgumentException("Marca invalida");
        }
    }

    public void power() {
        estaEncendido = !estaEncendido;
        System.out.println(estaEncendido ? "Encendido" : "Apagado");

    }

    public void mute() {
        estaMute = !estaMute;
        if (estaMute) {
            volumenAnterior = volumen;
            volumen = MIN_VOL;
            System.out.println("Mute");
        } else {
            volumen = volumenAnterior;
        }
    }

    private void validarTamnio(double tamanio) {
        if (tamanio <= 0) {
            throw new IllegalArgumentException("Tamaño invalido");
        }
    }

    private void validarCanal(int canalIngresado) {
        if (canalIngresado < MIN_CANAL || canalIngresado > MAX_CANAL) {
            throw new IllegalArgumentException("Canal Invalido");
        }
    }

    private void validarEncendido() {
        if (!estaEncendido) {
            throw new IllegalStateException("Televisor Apagado");
        }
    }

    private void desmutear() {
        if (estaMute) {
            mute();
        }
    }

    public void mostrarInfo() {

        validarEncendido();
        System.out.println(marca);
        System.out.println(canal);
        System.out.println(estaEncendido);
        System.out.println(volumen);
        System.out.println(tamanio);
        System.out.println(nroSerie);

    }

    public void mostrarVolumen() {
        if (estaMute) {
            System.out.println("Mute");
        } else {
            System.out.println("Volumen: " + volumen);
        }
    }

    public String getMarca() {
        return marca;
    }

    public void setCanal(int canal) {
        validarEncendido();
        validarCanal(canal);

        this.canal = canal;
        mostrarCanal();

    }

    private void mostrarCanal() {
        System.out.println("Canal: " + canal);
    }

    public void subirCanal() {
        System.out.println("Subiendo Canal!!");
        validarEncendido();
        if (canal < MAX_CANAL) {
            canal++;
            SET_CANAL = canal;
        } else {
            canal = MIN_CANAL;
        }
        mostrarCanal();
    }

    public void bajarCanal() {
        System.out.println("Bajando Canal!!");
        validarEncendido();

        if (canal > MIN_CANAL) {
            canal--;
            SET_CANAL = canal;
        } else {
            canal = MAX_CANAL;
        }
        mostrarCanal();
    }

    public void subirVolumen() {
        validarEncendido();
        desmutear();
        if (volumen < MAX_VOL) {
            volumen++;
            SET_VOLUMEN = volumen;
        }
        mostrarVolumen();
    }

    public void bajarVolumen() {
        validarEncendido();
        desmutear();
        if (volumen > MIN_VOL) {
            volumen--;
            SET_VOLUMEN = volumen;
        } else {
            mute();
        }
        mostrarVolumen();
    }

}
