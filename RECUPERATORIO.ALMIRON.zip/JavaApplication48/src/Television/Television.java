package Television;

public class Television {

    public static void main(String[] args) {
        Televisor tv1 = new Televisor("Sony", 45);

        ControlRemoto control = new ControlRemoto();

        control.setTv(tv1);

        control.encender();
        control.subirCanal();
    }
}
